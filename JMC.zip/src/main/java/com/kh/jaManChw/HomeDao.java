package com.kh.jaManChw;

import java.util.List;

import com.kh.jaManChw.dto.BoardOption;

public interface HomeDao {

	public List<BoardOption> selectAllBO();
}
